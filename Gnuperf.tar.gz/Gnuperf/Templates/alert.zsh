#!/bin/zsh
D="`date '+%Y%m%d%H'`"

for g in 10.129.0.32
  do
  /bin/iperf3 -t 60 -c $g > /usr/local/bin/Gnuperf/RawData/gnuperf.$g.log
  cat /usr/local/bin/Gnuperf/RawData/gnuperf.$g.log | grep KBytes | awk '{ print $3"\t"$5"\t"$7"\t"$9 }' > /usr/local/bin/Gnuperf/Gnudata/gnuperf.$g.dat
  done

for h in 101Common-Bandwidth.jpg 101Common-ReTries.jpg 101Common-Transfer.jpg
  do
    /bin/gnuplot < 101graph-tcp-data.gp
    if [[ -f /usr/local/bin/Gnuperf/Templates/$h ]]; then
      mv /usr/local/bin/Gnuperf/Templates/$h /usr/local/bin/Gnuperf/Send/$h
    fi
  done

Q=$(cat /usr/local/bin/Gnuperf/Gnudata/gnuperf.10.129.0.32.dat | awk -F'\t' '{ sum += $3 } END { print sum / NR }')

if [[ "$Q" -lt 800 ]]; then
    echo "iPerf Alert for 101Common" | mutt -a "/usr/local/bin/Gnuperf/Send/101Common-Bandwidth.jpg" "/usr/local/bin/Gnuperf/Send/101Common-Transfer.jpg" "/usr/local/bin/Gnuperf/Send/101Common-ReTries.jpg" -s "iPerf Alert 101Common" -- john.peterson@modernizingmedicine.com
fi
