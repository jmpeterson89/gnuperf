#!/bin/bash

D="`date '+%Y%m'`"

for h in 101Common 104Common 202Common 203Common Firewall
  do
    cd /usr/local/bin/Gnuperf/Log/; tar -zcvf $h.$D.tar.gz $h
    cd /usr/local/bin/;
    if [[ "$h" == "101Common" ]]; then
      ./gdrive upload --parent 0B1EeZHtolbdgNTZkVFdBOFROaEk /usr/local/bin/Gnuperf/Log/$h."$D".tar.gz
elif [[ "$h" == "104Common" ]]; then
      ./gdrive upload --parent 0B1EeZHtolbdgM2NoUEJmdFc2c0k /usr/local/bin/Gnuperf/Log/$h."$D".tar.gz
elif [[ "$h" == "202Common" ]]; then
  ./gdrive upload --parent 0B1EeZHtolbdgSFNsSDdRR3ZkdlU /usr/local/bin/Gnuperf/Log/$h."$D".tar.gz
elif [[ "$h" == "203Common" ]]; then
  ./gdrive upload --parent 0B1EeZHtolbdgV2toX3FmX1RleGs /usr/local/bin/Gnuperf/Log/$h."$D".tar.gz
elif [[ "$h" == "Firewall" ]]; then
  ./gdrive upload --parent 0B1EeZHtolbdgaGM1WWEzYUVuZjA /usr/local/bin/Gnuperf/Log/$h."$D".tar.gz
    fi
    rm -rf /usr/local/bin/Gnuperf/Log/$h/*.log
    cd /usr/local/bin/Gnuperf/Log; rm -rf $h."$D".tar.gz
  done
