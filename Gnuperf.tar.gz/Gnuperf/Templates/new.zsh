#!/bin/zsh
D="`date '+%Y%m%d%H'`"

for g in 10.129.0.31 10.129.0.32 10.129.0.33 10.129.0.34 10.129.0.35
  do
    /bin/iperf3 -t 60 -c $g > /usr/local/bin/Gnuperf/RawData/gnuperf.$g.log
    cat /usr/local/bin/Gnuperf/RawData/gnuperf.$g.log | grep KBytes | awk '{ print $3"\t"$5"\t"$7"\t"$9 }' > /usr/local/bin/Gnuperf/Gnudata/gnuperf.$g.dat
  done

P=$(sed -e '60d;59d;2d;1d'  /usr/local/bin/Gnuperf/Gnudata/gnuperf.10.129.0.31.dat | awk -F'\t' '{ sum += $3 } END { print sum / NR }')
Q=$(sed -e '60d;59d;2d;1d'  /usr/local/bin/Gnuperf/Gnudata/gnuperf.10.129.0.32.dat | awk -F'\t' '{ sum += $3 } END { print sum / NR }')
R=$(sed -e '60d;59d;2d;1d'  /usr/local/bin/Gnuperf/Gnudata/gnuperf.10.129.0.33.dat | awk -F'\t' '{ sum += $3 } END { print sum / NR }')
S=$(sed -e '60d;59d;2d;1d'  /usr/local/bin/Gnuperf/Gnudata/gnuperf.10.129.0.34.dat | awk -F'\t' '{ sum += $3 } END { print sum / NR }')
T=$(sed -e '60d;59d;2d;1d'  /usr/local/bin/Gnuperf/Gnudata/gnuperf.10.129.0.35.dat | awk -F'\t' '{ sum += $3 } END { print sum / NR }')

for h in 101Common-Bandwidth.jpg 101Common-ReTries.jpg 101Common-Transfer.jpg
  do
    /bin/gnuplot < 101graph-tcp-data.gp
    if [[ -f /usr/local/bin/Gnuperf/Templates/$h ]]; then
      mv /usr/local/bin/Gnuperf/Templates/$h /usr/local/bin/Gnuperf/Send/$h
    fi
  done

if [[ "$P" -lt 1000 ]]; then
  echo "iPerf Alert for 101Common" | mutt -a "/usr/local/bin/Gnuperf/Send/101Common-Bandwidth.jpg" "/usr/local/bin/Gnuperf/Send/101Common-Transfer.jpg" "/usr/local/bin/Gnuperf/Send/101Common-ReTries.jpg" -s "iPerf Alert 101Common" -- john.peterson@modernizingmedicine.com
fi

for i in 104Common-Bandwidth.jpg 104Common-ReTries.jpg 104Common-Transfer.jpg
  do
    /bin/gnuplot < 104graph-tcp-data.gp
    if [[ -f /usr/local/bin/Gnuperf/Templates/$i ]]; then
    mv /usr/local/bin/Gnuperf/Templates/$i /usr/local/bin/Gnuperf/Send/$i
    fi
done

if [[ "$Q" -lt 1000 ]]; then
  echo "iPerf Alert for 104Common" | mutt -a "/usr/local/bin/Gnuperf/Send/104Common-Bandwidth.jpg" "/usr/local/bin/Gnuperf/Send/104Common-Transfer.jpg" "/usr/local/bin/Gnuperf/Send/104Common-ReTries.jpg" -s "iPerf Alert 104Common" -- john.peterson@modernizingmedicine.com
fi

for j in 202Common-Bandwidth.jpg 202Common-ReTries.jpg 202Common-Transfer.jpg
  do
  /bin/gnuplot < 202graph-tcp-data.gp
    if [[ -f /usr/local/bin/Gnuperf/Templates/$j ]]; then
    mv /usr/local/bin/Gnuperf/Templates/$j /usr/local/bin/Gnuperf/Send/$j
  fi
done

if [[ "$R" -lt 1000 ]]; then
  echo "iPerf Alert for 202Common" | mutt -a "/usr/local/bin/Gnuperf/Send/202Common-Bandwidth.jpg" "/usr/local/bin/Gnuperf/Send/202Common-Transfer.jpg" "/usr/local/bin/Gnuperf/Send/202Common-ReTries.jpg" -s "iPerf Alert 202Common" -- john.peterson@modernizingmedicine.com
fi

for k in 203Common-Bandwidth.jpg 203Common-ReTries.jpg 203Common-Transfer.jpg
  do
    /bin/gnuplot < 203graph-tcp-data.gp
    if [[ -f /usr/local/bin/Gnuperf/Templates/$k ]]; then
      mv /usr/local/bin/Gnuperf/Templates/$k /usr/local/bin/Gnuperf/Send/$k
    fi
  done

if [[ "$S" -lt 1000 ]]; then
  echo "iPerf Alert for 203Common" | mutt -a "/usr/local/bin/Gnuperf/Send/203Common-Bandwidth.jpg" "/usr/local/bin/Gnuperf/Send/203Common-Transfer.jpg" "/usr/local/bin/Gnuperf/Send/203Common-ReTries.jpg" -s "iPerf Alert 203Common" -- john.peterson@modernizingmedicine.com
fi

for l in Firewall-Bandwidth.jpg Firewall-ReTries.jpg Firewall-Transfer.jpg
  do
      /bin/gnuplot < firewallgraph-tcp-data.gp
    if [[ -f /usr/local/bin/Gnuperf/Templates/$l ]]; then
        mv /usr/local/bin/Gnuperf/Templates/$l /usr/local/bin/Gnuperf/Send/$l
    fi
  done

if [[ "$T" -lt 1000 ]]; then
  echo "iPerf Alert for Firewall" | mutt -a "/usr/local/bin/Gnuperf/Send/Firewall-Bandwidth.jpg" "/usr/local/bin/Gnuperf/Send/Firewall-Transfer.jpg" "/usr/local/bin/Gnuperf/Send/Firewall-ReTries.jpg" -s "iPerf Alert Firewall" -- john.peterson@modernizingmedicine.com
fi

for m in 101 104 202 203 Firewall
  do
    rm -rf /usr/local/bin/Gnuperf/Send/$m*
  done


